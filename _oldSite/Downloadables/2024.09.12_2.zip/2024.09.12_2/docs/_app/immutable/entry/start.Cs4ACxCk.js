import{a as t}from"../chunks/entry.CAsZ9gJo.js";export{t as start};
