const állatok=['cica','kutya','malac','Medve']
function innit(){
    document.getElementById('body').innerHTML=állatok.map(v=> 
        `<div onclick="f('${v}')">${v}</div>`).join("")
}
const f= console.log